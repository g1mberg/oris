﻿namespace HttpServer.Services;

public class EmailServiceConst
{
    
}