﻿namespace HttpServer.Services;

public class EmailService
{
    
}