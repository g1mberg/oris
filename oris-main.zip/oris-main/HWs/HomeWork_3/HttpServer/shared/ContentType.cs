﻿namespace HttpServer.Shared;

public class ContentType
{
    
}