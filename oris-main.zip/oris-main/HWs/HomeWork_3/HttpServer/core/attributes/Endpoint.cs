﻿namespace HttpServer.core.Attributes;

public class Endpoint
{
    
}