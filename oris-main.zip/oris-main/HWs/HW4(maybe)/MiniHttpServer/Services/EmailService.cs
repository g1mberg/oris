﻿namespace MiniHttpServer.Services
{
    public static class EmailService
    {
        public static void SendEmail(string to, string subject, string message)
        {
            // TODO: ДЗ
        }
    }
}
